Graph Mining Assignment Part 2
Aayush Keval Shah
2019A7PS0137H

The folder contains following:
1) Part2_Q1 : the folder containing solution to first question


2) Part2_Q2 : the folder containing solution to second question


3) Part2_Q3 : the folder containing solution to third question


4) Part2_Q4 : the folder containing solution to fourth question


5)GRAPH MINING ASSIGNMENT PART_2.pdf :the report/documentation 


6) graph-1.txt input file


7) graph-2.txt input file

Please run all the codes (in C++) with g++ compiler.