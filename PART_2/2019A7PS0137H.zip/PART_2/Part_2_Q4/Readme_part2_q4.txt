Graph Mining Assignment Part 2
Aayush Keval Shah
2019A7PS0137H

The folder contains following:

1) 4_truss_CSR.cpp file contains the source code to solve the truss decomposition using CSR.

Run using the cpp g++ compiler.