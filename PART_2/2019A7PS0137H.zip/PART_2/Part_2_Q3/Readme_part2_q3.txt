Graph Mining Assignment Part 2
Aayush Keval Shah
2019A7PS0137H

The folder contains following:

1) 3_Pagerank.cpp file contains the source code to solve the Pagerank for given facebook pages.

2)facebook_edges.csv input file.

3)facebook_features.csv input file.

4)facebook_target.csv input file.

Run using the cpp g++ compiler.