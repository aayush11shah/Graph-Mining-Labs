GRAPH MINING ASSIGNMENT-1

Aayush Keval Shah
2019A7PS0137H

the folder consists of:
1) 2_Degree_checker.cpp  -> main source code
2) adjList_degreeFreq.txt  -> stores the degree frequencies form adjacency list
3) CSR_degreeFreq.txt   -> stores the degree frequencies from CSR
4) plotter.py  -> plots the Degree distribution curve for degree frequencies obtained from adjacency list and CSR
5) Degree_Comparison.png   -> The png img=age file generated from plotter.py comparing the degree distributions
 
Make sure to install the matplotlib and numpy python3 libraries before running the code.

First Run the 2_Degree_checker.cpp file with g++.

Then after the text files are created/updated, Run the "python plotter.py" file in the terminal.

The plot will be visible which can be magnified and can be analyzed easily.

The plot image is stored also.