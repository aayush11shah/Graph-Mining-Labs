GRAPH MINING ASSIGNMENT-1

Aayush Keval Shah
2019A7PS0137H

the folder consists of only 3_N_cycles file.

the length of cycle to find is hardcoded in the main method directly in the countCycles method call. Please change that for any other cycle size. 
Run the file with g++.