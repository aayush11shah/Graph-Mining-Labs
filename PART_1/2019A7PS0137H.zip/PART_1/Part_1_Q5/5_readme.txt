GRAPH MINING ASSIGNMENT-1

Aayush Keval Shah
2019A7PS0137H

the folder consists of only 5_Largest_component.cpp file.
Run the file with g++.