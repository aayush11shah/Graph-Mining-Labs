GRAPH MINING ASSIGNMENT-1

Aayush Keval Shah
2019A7PS0137H

the folder consists of only 1_Graph_Reader.cpp file.
Run the file with g++ and PLEASE UNCOMMENT the display functions of adjacency list and CSR representation in the main method. They were commented to make sure that very large lists dont get print suddenly.