GRAPH MINING ASSIGNMENT-1

Aayush Keval Shah
2019A7PS0137H

This folder contains 5 sub folders, one for each question and 3 graph input files:
1) Part_1_Q1

2) Part_1_Q2

3) Part_1_Q3

4) Part_1_Q4

5) Part_1_Q5

6) graph-1.txt

7) graph-2.txt

8) input.txt -> a test input file

9) Assignment part 1 - report

All the main source codes are written in C++ language and preferred standard used is C++14.
Each subfolder has its own readme file. Please refer to it before running the source code
